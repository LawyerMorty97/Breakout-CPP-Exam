//
// Created by Mathias Berntsen on 23/04/2019.
//

#ifndef C_EXAM_ELEMENT_H
#define C_EXAM_ELEMENT_H

#include ""

class Element {
public:
protected:

};


#endif //C_EXAM_ELEMENT_H
