//
// Created by Mathias Berntsen on 18/02/2019.
//

#include "Image.h"

Image::Image(std::string filename, float x, float y, float w, float h) {
    //window = SDL_GL_GetCurrentWindow();
    //renderer = SDL_GetRenderer(window);
    window = GetWindow();
    renderer = GetRenderer();

    this->filename = filename;

    //surface = SDL_LoadBMP(Utils::stringToChar("images/" + filename));
    std::string file = "content/images/" + filename;
    surface = IMG_Load(file.c_str());

    if (surface == nullptr) {
        Utils::error_sdl("Failed to load image '" + filename + "' (" + IMG_GetError() + ".");
        return;
    }

    texture = CreateTexture(surface);
    setPosition(Set, x, y);
    setSize(Set, w, h);
    //SDL_FreeSurface(surface);

    m_CanRender = true;
}

void Image::ChangeImage(std::string name) {
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);

    std::string file = "content/images/" + filename;
    surface = IMG_Load(file.c_str());

    if (surface == nullptr) {
        Utils::error_sdl("Failed to load image '" + filename + "' (" + IMG_GetError() + ".");
        return;
    }

    texture = CreateTexture(surface);
}

void Image::setViewable(bool toggle) {
    m_viewable = toggle;
}

bool Image::isViewable() {
    return m_CanRender ? m_viewable : false;
}

std::pair<float, float> Image::GetSurfaceSize() {
    return {surface->w, surface->h};
}

std::tuple<float, float, float, float> Image::getColor() {
    Uint8 r, g, b, a;

    SDL_GetTextureColorMod(texture, &r, &g, &b);
    SDL_GetTextureAlphaMod(texture, &a);

    return {r, g, b, a};
}

void Image::setColor(float r, float g, float b, float a) {
    SDL_SetTextureColorMod(texture, r, g, b);
    SDL_SetTextureAlphaMod(texture, a);
}

bool Image::Draw() {
    if (!m_CanRender || !m_viewable)
        return false;

    SDL_RenderCopy(renderer, texture, nullptr, &rect);

    return true;
}

Image::~Image() {
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}